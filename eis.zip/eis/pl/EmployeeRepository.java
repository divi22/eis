package com.cg.eis.pl;
import java.time.LocalDate;
import java.util.*;
import com.cg.eis.bean.*;
public class EmployeeRepository {
 // Department dept=new Department();

 public static List<Department> getDepartments()
 {
 List<Department> dlist=new ArrayList<>();
 dlist.add(new Department(10,"IT",100));
 dlist.add(new Department(20,"Sales",101));
 dlist.add(new Department(30,"Marketing",102));
 dlist.add(new Department(40,"HR",104));
 return dlist;
 }
 public static List<Employee> getEmployees()
 {
 List<Employee> elist=new ArrayList<>();
 elist.add(new Employee(100,"Yuvaraj","Capgemini","yuvi@cg.com","9867221020",LocalDate.of(2012,5,25),"President",50000.00,null,new Department(10,"IT",100)));
 elist.add(new Employee(104,"Prabhu","Capgemini","prabhu@cg.com","9867221100",LocalDate.of(2015,8,2),"Sales_Mgr",45000.00,100,null));
 elist.add(new Employee(105,"Praga","Capgemini","praga@cg.com","8547123069",LocalDate.of(2015,8,2),"Sales_Mgr",45000.00,null,new Department(20,"Sales",101)));
 elist.add(new Employee(101,"Vignesh","Capgemini","vignesh@cg.com","9867221020",LocalDate.of(2015,8,2),"Sales_Mgr",45000.00,100,new Department(40,"Sales",101)));
 elist.add(new Employee(102,"Gokul","Capgemini","gokul@cg.com","8143790342",LocalDate.of(2011,7,21),"Marketing",15000.00,100,new Department(30,"Marketing",102)));
 elist.add(new Employee(103,"Rahman","Capgemini","rahman@cg.com","874569632",LocalDate.of(2010,8,2),"Sales_Mgr",45000.00,100,null));
 elist.add(new Employee(106,"Jagadeesh","Capgemini","jaga@cg.com","8767221020",LocalDate.of(2015,8,2),"Sales_Mgr",45000.00,100,new Department(20,"Sales",101)));
 
 return elist;
 }

}

